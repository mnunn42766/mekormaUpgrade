SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_VisitorToContact](
	[VisitorToContactID] [int] IDENTITY(1,1) NOT NULL,
	[VisitorToContactVisitorGUID] [uniqueidentifier] NOT NULL,
	[VisitorToContactContactID] [int] NOT NULL,
 CONSTRAINT [PK_OM_VisitorToContact] PRIMARY KEY CLUSTERED 
(
	[VisitorToContactID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_OM_VisitorToContact_VisitorToContactContactID] ON [dbo].[OM_VisitorToContact]
(
	[VisitorToContactContactID] ASC
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_OM_VisitorToContact_VisitorToContactVisitorGUID] ON [dbo].[OM_VisitorToContact]
(
	[VisitorToContactVisitorGUID] ASC
)
GO
ALTER TABLE [dbo].[OM_VisitorToContact] ADD  CONSTRAINT [DEFAULT_OM_VisitorToContact_VisitorToContactVisitorGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [VisitorToContactVisitorGUID]
GO
ALTER TABLE [dbo].[OM_VisitorToContact] ADD  CONSTRAINT [DEFAULT_OM_VisitorToContact_VisitorToContactContactID]  DEFAULT ((0)) FOR [VisitorToContactContactID]
GO
ALTER TABLE [dbo].[OM_VisitorToContact]  WITH CHECK ADD  CONSTRAINT [FK_OM_VisitorToContact_OM_Contact_Cascade] FOREIGN KEY([VisitorToContactContactID])
REFERENCES [dbo].[OM_Contact] ([ContactID])
GO
ALTER TABLE [dbo].[OM_VisitorToContact] CHECK CONSTRAINT [FK_OM_VisitorToContact_OM_Contact_Cascade]
GO
