﻿// AssemblyInfo.cs created with MonoDevelop
//
// Author:
//    Rudi Pettazzi <rudi.pettazzi@gmail.com>
//
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Ude.Tests")]
[assembly: AssemblyDescription("Unit tests for Ude")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Ude.Tests")]
[assembly: AssemblyCopyright("Copyright © rudi pettazzi 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]

