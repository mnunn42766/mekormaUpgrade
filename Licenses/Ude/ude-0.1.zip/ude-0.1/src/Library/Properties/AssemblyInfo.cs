// AssemblyInfo.cs created with MonoDevelop
//
// Author:
//    Rudi Pettazzi <rudi.pettazzi@gmail.com>
//
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Ude")]
[assembly: AssemblyDescription("C# port of Mozilla Universal Charset Detector")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Ude")]
[assembly: AssemblyCopyright("Copyright © 2009 Rudi Pettazzi <rudi.pettazzi@gmail.com>")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
[assembly: AssemblyInformationalVersion("0.1.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]



