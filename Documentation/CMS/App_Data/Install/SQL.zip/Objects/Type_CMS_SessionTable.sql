CREATE TYPE [dbo].[Type_CMS_SessionTable] AS TABLE(
	[SessionIdentificator] [nvarchar](50) NOT NULL,
	[SessionUserID] [int] NULL,
	[SessionLocation] [nvarchar](450) NULL,
	[SessionLastActive] [datetime2](7) NOT NULL,
	[SessionLastLogon] [datetime2](7) NULL,
	[SessionExpires] [datetime2](7) NOT NULL,
	[SessionExpired] [bit] NOT NULL,
	[SessionSiteID] [int] NULL,
	[SessionUserIsHidden] [bit] NOT NULL,
	[SessionFullName] [nvarchar](450) NULL,
	[SessionEmail] [nvarchar](254) NULL,
	[SessionUserName] [nvarchar](254) NULL,
	[SessionNickName] [nvarchar](254) NULL,
	[SessionUserCreated] [datetime2](7) NULL,
	[SessionContactID] [int] NULL
)
GO
