SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_ContactRole](
	[ContactRoleID] [int] IDENTITY(1,1) NOT NULL,
	[ContactRoleName] [nvarchar](200) NOT NULL,
	[ContactRoleDisplayName] [nvarchar](200) NOT NULL,
	[ContactRoleDescription] [nvarchar](max) NULL,
 CONSTRAINT [PK_OM_ContactRole] PRIMARY KEY CLUSTERED 
(
	[ContactRoleID] ASC
)
)

GO
ALTER TABLE [dbo].[OM_ContactRole] ADD  CONSTRAINT [DEFAULT_OM_ContactRole_ContactRoleName]  DEFAULT ('') FOR [ContactRoleName]
GO
ALTER TABLE [dbo].[OM_ContactRole] ADD  CONSTRAINT [DEFAULT_OM_ContactRole_ContactRoleDisplayName]  DEFAULT ('') FOR [ContactRoleDisplayName]
GO
